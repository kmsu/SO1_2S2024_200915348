Comandos para inicializar Go

go mod init go-client

luego el goolang setup del archivo doc.md

se puede usar el comando `touch nombre.go` para generar un archivo de go 